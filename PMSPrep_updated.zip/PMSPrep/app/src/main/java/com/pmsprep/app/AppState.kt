package com.pmsprep.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class AppState(ctx: Context) {
    private val sp = ctx.getSharedPreferences("pms_prefs", Context.MODE_PRIVATE)

    val index: List<IndexEntry> = Repo.loadIndex(ctx)
    val topics: Map<Int, Topic> = index.mapNotNull { e ->
        Repo.loadTopic(ctx, e)?.let { e.no to it }
    }.toMap()

    /** Difficult terms from all added topics (lower-case term -> item). */
    val glossary: Map<String, VocabItem> = buildMap {
        topics.values.flatMap { it.vocab }.forEach { v ->
            val t = v.term.lowercase()
            put(t, v)
            // "Foreign direct investment (FDI)" is also matched as "foreign direct investment" and "fdi"
            val m = Regex("^(.+?)\\s*\\((.+)\\)$").find(t)
            if (m != null) {
                put(m.groupValues[1].trim(), v)
                put(m.groupValues[2].trim(), v)
            }
        }
    }
    val glossaryRegex: Regex? = glossary.keys.sortedByDescending { it.length }
        .takeIf { it.isNotEmpty() }
        ?.let { keys ->
            Regex("\\b(" + keys.joinToString("|") { Regex.escape(it) } + ")(?:s|es)?\\b", RegexOption.IGNORE_CASE)
        }

    var bookmarks by mutableStateOf(sp.getStringSet("bookmarks", emptySet())!!.toSet())
        private set
    var revised by mutableStateOf(sp.getStringSet("revised", emptySet())!!.toSet())
        private set
    var themeMode by mutableIntStateOf(sp.getInt("theme", 0)) // 0 auto, 1 light, 2 dark
        private set
    var srs by mutableStateOf(loadSrs())
        private set
    var wrongKeys by mutableStateOf(sp.getStringSet("wrong", emptySet())!!.toSet())
        private set
    var mockHistory by mutableStateOf(loadMock())
        private set
    var palette by mutableIntStateOf(sp.getInt("palette", 0))
        private set
    var fontScale by mutableFloatStateOf(sp.getFloat("font_scale", 1f))
        private set
    var onboarded by mutableStateOf(sp.getBoolean("onboarded", false))
        private set

    var apiKey by mutableStateOf(sp.getString("api_key", "") ?: "")
        private set

    var provider by mutableStateOf(sp.getString("ai_provider", "gemini") ?: "gemini")
        private set
    var geminiKey by mutableStateOf(sp.getString("gemini_key", "") ?: "")
        private set
    var geminiModel by mutableStateOf(sp.getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash")
        private set

    fun changeProvider(p: String) { provider = p; sp.edit().putString("ai_provider", p).apply() }
    fun changeGeminiKey(k: String) { geminiKey = k.trim(); sp.edit().putString("gemini_key", geminiKey).apply() }
    fun changeGeminiModel(m: String) {
        geminiModel = m.trim().ifEmpty { "gemini-2.5-flash" }
        sp.edit().putString("gemini_model", geminiModel).apply()
    }
    fun activeKey(): String = if (provider == "gemini") geminiKey else apiKey

    fun changeApiKey(k: String) {
        apiKey = k.trim()
        sp.edit().putString("api_key", apiKey).apply()
    }

    fun aiCached(k: String): String? = sp.getString("ai_$k", null)
    fun aiSave(k: String, v: String) { sp.edit().putString("ai_$k", v).apply() }
    fun aiClear(k: String) { sp.edit().remove("ai_$k").apply() }

    fun myNote(no: Int): String = sp.getString("note_$no", "") ?: ""
    fun saveNote(no: Int, text: String) { sp.edit().putString("note_$no", text).apply() }

    fun toggleBookmark(key: String) {
        bookmarks = if (key in bookmarks) bookmarks - key else bookmarks + key
        sp.edit().putStringSet("bookmarks", bookmarks.toSet()).apply()
    }

    private val intervals = intArrayOf(3, 7, 15)

    private fun today(): Long = System.currentTimeMillis() / 86_400_000L

    private fun loadSrs(): Map<Int, Pair<Long, Int>> = index.mapNotNull { e ->
        val last = sp.getLong("srs_last_${e.no}", -1L)
        when {
            last >= 0 -> e.no to (last to sp.getInt("srs_level_${e.no}", 0))
            e.no.toString() in revised -> e.no to (today() to 0)
            else -> null
        }
    }.toMap()

    private fun loadMock(): List<String> =
        (sp.getString("mock_history", "") ?: "").split(";").filter { it.isNotBlank() }

    fun toggleRevised(no: Int) {
        val k = no.toString()
        if (k in revised) {
            revised = revised - k
            srs = srs - no
            sp.edit().remove("srs_last_$no").remove("srs_level_$no").apply()
        } else {
            revised = revised + k
            srs = srs + (no to (today() to 0))
            sp.edit().putLong("srs_last_$no", today()).putInt("srs_level_$no", 0).apply()
        }
        sp.edit().putStringSet("revised", revised.toSet()).apply()
    }

    fun markReviewed(no: Int) {
        val cur = srs[no] ?: return
        val level = (cur.second + 1).coerceAtMost(3)
        srs = srs + (no to (today() to level))
        sp.edit().putLong("srs_last_$no", today()).putInt("srs_level_$no", level).apply()
    }

    fun reviewLevel(no: Int): Int = srs[no]?.second ?: 0

    /** Days until the next spaced review; null if not scheduled or all 3 reviews are done. */
    fun daysUntilReview(no: Int): Int? {
        val cur = srs[no] ?: return null
        if (cur.second >= 3) return null
        return (cur.first + intervals[cur.second] - today()).toInt()
    }

    fun isDue(no: Int): Boolean = (daysUntilReview(no) ?: 1) <= 0

    fun dueTopics(): List<Topic> = topics.values.filter { isDue(it.no) }

    private fun key(q: Mcq) = "${q.topicNo}:${q.idx}"

    fun addWrong(q: Mcq) {
        if (key(q) in wrongKeys) return
        wrongKeys = wrongKeys + key(q)
        sp.edit().putStringSet("wrong", wrongKeys.toSet()).apply()
    }

    fun removeWrong(q: Mcq) {
        if (key(q) !in wrongKeys) return
        wrongKeys = wrongKeys - key(q)
        sp.edit().putStringSet("wrong", wrongKeys.toSet()).apply()
    }

    fun wrongMcqs(): List<Mcq> =
        topics.values.flatMap { t -> t.mcqs.filter { key(it) in wrongKeys } }

    fun addMock(score: Int, total: Int) {
        mockHistory = (listOf("${System.currentTimeMillis()}|$score|$total") + mockHistory).take(10)
        sp.edit().putString("mock_history", mockHistory.joinToString(";")).apply()
    }

    fun changeTheme(mode: Int) {
        themeMode = mode
        sp.edit().putInt("theme", mode).apply()
    }

    fun changePalette(index: Int) {
        palette = index
        sp.edit().putInt("palette", index).apply()
    }

    fun changeFontScale(scale: Float) {
        fontScale = scale
        sp.edit().putFloat("font_scale", scale).apply()
    }

    fun finishOnboarding() {
        onboarded = true
        sp.edit().putBoolean("onboarded", true).apply()
    }

    fun resetProgress() {
        val ed = sp.edit()
        index.forEach { ed.remove("srs_last_${it.no}").remove("srs_level_${it.no}") }
        ed.putStringSet("bookmarks", emptySet()).putStringSet("revised", emptySet())
            .putStringSet("wrong", emptySet()).remove("mock_history").apply()
        bookmarks = emptySet()
        revised = emptySet()
        srs = emptyMap()
        wrongKeys = emptySet()
        mockHistory = emptyList()
    }

    fun vocabFor(no: Int?): List<VocabItem> =
        if (no == null) topics.values.flatMap { it.vocab } else topics[no]?.vocab ?: emptyList()
}

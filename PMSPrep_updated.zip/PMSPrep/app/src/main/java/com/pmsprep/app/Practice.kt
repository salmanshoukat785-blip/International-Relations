package com.pmsprep.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- MCQs tab ----------

@Composable
fun QuizTab(state: AppState, open: (Screen) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("MCQs")
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val all = state.topics.values.sumOf { it.mcqs.size }
            item {
                Card(Modifier.fillMaxWidth().clickable(enabled = all > 0) { open(Screen.QuizOf(null)) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Mixed quiz (all topics)", fontWeight = FontWeight.Bold)
                        Text("$all questions, shuffled", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth().clickable { open(Screen.MockSetup) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Timed mock test", fontWeight = FontWeight.Bold)
                        Text(
                            "Exam-style, one minute per question, with score breakdown",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                val n = state.wrongMcqs().size
                Card(Modifier.fillMaxWidth().clickable(enabled = n > 0) { open(Screen.QuizBank) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Wrong answers bank", fontWeight = FontWeight.Bold)
                        Text(
                            if (n > 0) "$n questions to review. Answer correctly to clear them."
                            else "Empty. Questions you get wrong will collect here.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item { Text("Topic-wise", fontWeight = FontWeight.Bold) }
            items(state.topics.values.toList()) { t ->
                Card(Modifier.fillMaxWidth().clickable { open(Screen.QuizOf(t.no)) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Topic ${t.no}: ${t.title}")
                        Text("${t.mcqs.size} questions", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

// ---------- Practice quiz (topic, mixed, wrong-answers bank) ----------

@Composable
fun QuizScreen(state: AppState, no: Int?, back: () -> Unit) {
    val source = remember(no) {
        if (no == null) state.topics.values.flatMap { it.mcqs }.shuffled()
        else state.topics[no]?.mcqs ?: emptyList()
    }
    QuizRunner(
        title = if (no == null) "Mixed quiz" else "Topic $no quiz",
        source = source,
        back = back,
        onAnswered = { q, ok -> if (!ok) state.addWrong(q) }
    )
}

@Composable
fun BankQuizScreen(state: AppState, back: () -> Unit) {
    val source = remember { state.wrongMcqs().shuffled() }
    QuizRunner(
        title = "Wrong answers bank",
        source = source,
        back = back,
        onAnswered = { q, ok -> if (ok) state.removeWrong(q) else state.addWrong(q) }
    )
}

@Composable
fun QuizRunner(title: String, source: List<Mcq>, back: () -> Unit, onAnswered: (Mcq, Boolean) -> Unit) {
    val ctx = LocalContext.current
    var questions by remember { mutableStateOf(source) }
    var i by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var wrong by remember { mutableStateOf(listOf<Mcq>()) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title, onBack = back)
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            if (questions.isEmpty()) {
                Text("No questions here yet.")
            } else if (i >= questions.size) {
                Text(
                    text = "Score: $score / ${questions.size}",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                if (wrong.isNotEmpty()) {
                    Button(onClick = {
                        questions = wrong; wrong = emptyList(); i = 0; score = 0; selected = null
                    }) { Text("Retry ${wrong.size} wrong") }
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedButton(onClick = {
                    questions = source.shuffled(); wrong = emptyList(); i = 0; score = 0; selected = null
                }) { Text("Restart") }
            } else {
                val q = questions[i]
                LinearProgressIndicator(
                    progress = { i.toFloat() / questions.size },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text(text = "Question ${i + 1} of ${questions.size}", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                Text(text = q.q, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                q.options.forEachIndexed { oi, opt ->
                    val sel = selected
                    val color = when {
                        sel == null -> MaterialTheme.colorScheme.surfaceVariant
                        oi == q.answer -> MaterialTheme.colorScheme.primaryContainer
                        oi == sel -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = color),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable(enabled = sel == null) {
                                selected = oi
                                val ok = oi == q.answer
                                if (ok) score++ else wrong = wrong + q
                                onAnswered(q, ok)
                            }
                    ) {
                        Text(text = "${"ABCD"[oi]}. $opt", modifier = Modifier.padding(14.dp))
                    }
                }
                if (selected != null) {
                    if (q.explanation.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(text = q.explanation)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { i++; selected = null }) {
                            Text(if (i == questions.size - 1) "Finish" else "Next")
                        }
                        TextButton(onClick = { copyText(ctx, "MCQ", mcqText(q)) }) { Text("Copy") }
                        TextButton(onClick = { shareText(ctx, mcqText(q)) }) { Text("Share") }
                    }
                }
            }
        }
    }
}

// ---------- Timed mock test ----------

private fun fmtTime(sec: Int): String = "%02d:%02d".format(sec / 60, sec % 60)

@Composable
fun MockSetupScreen(state: AppState, back: () -> Unit, open: (Screen) -> Unit) {
    val available = state.topics.values.sumOf { it.mcqs.size }
    val options = listOf(10, 25, 50).filter { it <= available }.ifEmpty { listOf(available) }
    var count by remember { mutableIntStateOf(if (25 in options) 25 else options.last()) }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Timed mock test", onBack = back)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    "Exam-style test: questions are picked at random from all added topics. " +
                        "You get one minute per question. Answers are shown only after you submit, " +
                        "and wrong or unanswered questions go to your Wrong answers bank."
                )
            }
            if (available == 0) {
                item { Text("No questions available yet.") }
            } else {
                item {
                    Text("Number of questions", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        options.forEach { n ->
                            FilterChip(
                                selected = count == n,
                                onClick = { count = n },
                                label = { Text("$n") }
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Time allowed: $count minutes", style = MaterialTheme.typography.bodySmall)
                }
                item {
                    Button(onClick = { open(Screen.MockRun(count)) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Start test")
                    }
                }
            }
            if (state.mockHistory.isNotEmpty()) {
                item { Text("Recent attempts", fontWeight = FontWeight.Bold) }
                items(state.mockHistory) { row ->
                    val p = row.split("|")
                    if (p.size == 3) {
                        val whenText = p[0].toLongOrNull()?.let { fmt.format(Date(it)) } ?: ""
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp)) {
                                Text(text = whenText, modifier = Modifier.weight(1f))
                                Text(text = "${p[1]} / ${p[2]}", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MockTestScreen(state: AppState, count: Int, back: () -> Unit) {
    val qs = remember(count) { state.topics.values.flatMap { it.mcqs }.shuffled().take(count) }
    val answers = remember(count) { mutableStateListOf<Int?>().apply { repeat(qs.size) { add(null) } } }
    var idx by remember { mutableIntStateOf(0) }
    var remaining by remember { mutableIntStateOf(qs.size * 60) }
    var finished by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }

    LaunchedEffect(finished) {
        while (!finished && remaining > 0) {
            delay(1000L)
            remaining -= 1
        }
        if (remaining <= 0) finished = true
    }
    LaunchedEffect(finished) {
        if (finished && !saved && qs.isNotEmpty()) {
            saved = true
            val sc = qs.indices.count { answers[it] == qs[it].answer }
            state.addMock(sc, qs.size)
            qs.indices.forEach { if (answers[it] != qs[it].answer) state.addWrong(qs[it]) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Mock test", onBack = back)
        if (qs.isEmpty()) {
            Text("No questions available yet.", modifier = Modifier.padding(16.dp))
        } else if (!finished) {
            val q = qs[idx]
            Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Question ${idx + 1} of ${qs.size}", modifier = Modifier.weight(1f))
                    Text(
                        text = fmtTime(remaining),
                        fontWeight = FontWeight.Bold,
                        color = if (remaining < 60) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(text = q.q, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                q.options.forEachIndexed { oi, opt ->
                    val chosen = answers[idx] == oi
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (chosen) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { answers[idx] = oi }
                    ) {
                        Text(text = "${"ABCD"[oi]}. $opt", modifier = Modifier.padding(14.dp))
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = idx > 0,
                        onClick = { idx-- },
                        modifier = Modifier.weight(1f)
                    ) { Text("Previous") }
                    OutlinedButton(
                        enabled = idx < qs.size - 1,
                        onClick = { idx++ },
                        modifier = Modifier.weight(1f)
                    ) { Text("Next") }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Submit test")
                }
            }
        } else {
            val score = qs.indices.count { answers[it] == qs[it].answer }
            val byTopic = qs.indices.groupBy { qs[it].topicNo }.toSortedMap()
            val missed = qs.indices.filter { answers[it] != qs[it].answer }
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(
                        text = "Score: $score / ${qs.size}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Time used: ${fmtTime(qs.size * 60 - remaining)}")
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Wrong and unanswered questions were added to your Wrong answers bank.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                item { Text("By topic", fontWeight = FontWeight.Bold) }
                items(byTopic.entries.toList()) { (no, list) ->
                    val right = list.count { answers[it] == qs[it].answer }
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp)) {
                            Text(
                                text = "Topic $no: ${state.topics[no]?.title ?: ""}",
                                modifier = Modifier.weight(1f)
                            )
                            Text(text = "$right / ${list.size}", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (missed.isNotEmpty()) item { Text("Review: wrong or unanswered", fontWeight = FontWeight.Bold) }
                items(missed) { qi ->
                    val q = qs[qi]
                    val mine = answers[qi]
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(text = q.q, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Your answer: " +
                                    (if (mine == null) "not answered" else "${"ABCD"[mine]}. ${q.options[mine]}")
                            )
                            Text(text = "Correct: ${"ABCD"[q.answer]}. ${q.options[q.answer]}")
                            if (q.explanation.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(text = q.explanation, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                item {
                    Button(onClick = back, modifier = Modifier.fillMaxWidth()) { Text("Done") }
                }
            }
        }
    }
    if (confirm) {
        val unanswered = answers.count { it == null }
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Submit test?") },
            text = {
                Text(
                    if (unanswered > 0) "$unanswered question(s) are still unanswered."
                    else "All questions are answered."
                )
            },
            confirmButton = { TextButton(onClick = { confirm = false; finished = true }) { Text("Submit") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Keep working") } }
        )
    }
}

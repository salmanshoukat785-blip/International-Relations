package com.pmsprep.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val state = AppState(applicationContext)
        setContent {
            val dark = when (state.themeMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            val base = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(base.density, base.fontScale * state.fontScale)
            ) {
                MaterialTheme(colorScheme = colorSchemeFor(state.palette, dark)) {
                    Surface(modifier = Modifier.fillMaxSize()) { Root(state) }
                }
            }
        }
    }
}

@Composable
fun Root(state: AppState) {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1800)
        splash = false
    }
    when {
        splash -> SplashScreen()
        !state.onboarded -> OnboardingScreen(onDone = { state.finishOnboarding() })
        else -> AppRoot(state)
    }
}

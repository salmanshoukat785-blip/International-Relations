package com.pmsprep.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Revise tab ----------

@Composable
fun ReviseTab(state: AppState, open: (Screen) -> Unit) {
    val cardCount = remember(state) { buildCards(state, null).size }
    val events = remember(state) { buildTimeline(state).size }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Last-minute revision")
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth().clickable(enabled = cardCount > 0) { open(Screen.QuickRevise) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Quick revision cards", fontWeight = FontWeight.Bold)
                        Text(
                            "$cardCount swipeable cards: key points and revision points of all topics",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth().clickable { open(Screen.MasterTimeline) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Master timeline", fontWeight = FontWeight.Bold)
                        Text(
                            "$events dated events from all topics, filter by topic or region",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                Text(
                    text = "Topic outlines",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(state.topics.values.sortedBy { it.no }) { t ->
                Card(Modifier.fillMaxWidth().clickable { open(Screen.OutlineOf(t.no)) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Topic ${t.no}: ${t.title}")
                        Text("${t.sections.size} main points", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChipRow(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

// ---------- Quick revision (swipeable cards) ----------

private data class RevCard(
    val topicNo: Int,
    val topicTitle: String,
    val title: String,
    val bullets: List<String>,
    val saveKey: String?
)

private fun buildCards(state: AppState, topicNo: Int?): List<RevCard> {
    val out = mutableListOf<RevCard>()
    state.topics.values.sortedBy { it.no }.filter { topicNo == null || it.no == topicNo }.forEach { t ->
        t.sections.forEachIndexed { i, s ->
            out.add(
                RevCard(
                    t.no, t.title, s.title,
                    if (s.keyPoints.isNotEmpty()) s.keyPoints else listOf(s.short),
                    "${t.no}:$i"
                )
            )
        }
        t.revision.chunked(4).forEachIndexed { ci, chunk ->
            val suffix = if (t.revision.size > 4) " (${ci + 1})" else ""
            out.add(RevCard(t.no, t.title, "Key points for revision$suffix", chunk, null))
        }
    }
    return out
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun QuickReviseScreen(state: AppState, back: () -> Unit) {
    var topicSel by remember { mutableStateOf<Int?>(null) }
    var shuffle by remember { mutableStateOf(false) }
    val cards = remember(topicSel, shuffle) {
        val base = buildCards(state, topicSel)
        if (shuffle) base.shuffled() else base
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Quick revision", onBack = back)
        ChipRow {
            FilterChip(selected = topicSel == null, onClick = { topicSel = null }, label = { Text("All") })
            state.topics.keys.sorted().forEach { n ->
                FilterChip(selected = topicSel == n, onClick = { topicSel = n }, label = { Text("Topic $n") })
            }
        }
        ChipRow {
            FilterChip(selected = shuffle, onClick = { shuffle = !shuffle }, label = { Text("Shuffle") })
        }
        if (cards.isEmpty()) {
            Text("No cards yet.", modifier = Modifier.padding(16.dp))
        } else {
            key(topicSel, shuffle) {
                val pager = rememberPagerState(pageCount = { cards.size })
                Text(
                    text = "${pager.currentPage + 1} / ${cards.size}  \u00B7  swipe left or right",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                HorizontalPager(
                    state = pager,
                    pageSpacing = 8.dp,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) { page ->
                    RevisionCard(state, cards[page])
                }
            }
        }
    }
}

@Composable
private fun RevisionCard(state: AppState, c: RevCard) {
    Card(Modifier.fillMaxSize()) {
        Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Topic ${c.topicNo} \u00B7 ${c.topicTitle}",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f)
                )
                if (c.saveKey != null) {
                    val saved = c.saveKey in state.bookmarks
                    IconButton(onClick = { state.toggleBookmark(c.saveKey) }) {
                        Text(text = if (saved) "\u2605" else "\u2606", fontSize = 22.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(text = c.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            c.bullets.forEach { b ->
                GText(state, "\u2022 $b")
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

// ---------- Master timeline ----------

private data class TlItem(
    val sortYear: Int,
    val year: String,
    val event: String,
    val topicNo: Int,
    val region: String
)

private val regionRules = listOf(
    "South Asia" to Regex("India|Pakistan|Kashmir|Indus|Afghanistan|Bangladesh|Nepal|Sri Lanka|Bhutan|Maldives|SAARC", RegexOption.IGNORE_CASE),
    "Middle East" to Regex("Iran|Iraq|Israel|Gaza|Gulf|Saudi|Syria|Yemen|Suez|Middle East|Arab|Palestin", RegexOption.IGNORE_CASE),
    "Asia-Pacific" to Regex("China|Japan|Korea|ASEAN|Taiwan|Indo-Pacific|Belt and Road|Quad|AUKUS|Vietnam|Pacific|Singapore", RegexOption.IGNORE_CASE),
    "Americas" to Regex("United States|America|Washington|Cuba|Monroe|Marshall Plan|Canada|Brazil", RegexOption.IGNORE_CASE),
    "Europe" to Regex("Europe|NATO|Warsaw|Westphalia|Vienna|Versailles|Berlin|Soviet|Russia|Ukraine|Britain|France|German|Paris", RegexOption.IGNORE_CASE)
)

private fun regionOf(text: String): String =
    regionRules.firstOrNull { it.second.containsMatchIn(text) }?.first ?: "Global"

private fun buildTimeline(state: AppState): List<TlItem> =
    state.topics.values.flatMap { t ->
        t.chronology.map { c ->
            TlItem(
                sortYear = Regex("\\d{3,4}").find(c.year)?.value?.toIntOrNull() ?: 0,
                year = c.year,
                event = c.event,
                topicNo = t.no,
                region = regionOf(c.event)
            )
        }
    }.sortedWith(compareBy({ it.sortYear }, { it.topicNo }))

@Composable
fun MasterTimelineScreen(state: AppState, back: () -> Unit) {
    val all = remember(state) { buildTimeline(state) }
    var topicSel by remember { mutableStateOf<Int?>(null) }
    var regionSel by remember { mutableStateOf<String?>(null) }
    val topicsWith = all.map { it.topicNo }.distinct().sorted()
    val regions = all.map { it.region }.distinct().sorted()
    val shown = all.filter {
        (topicSel == null || it.topicNo == topicSel) && (regionSel == null || it.region == regionSel)
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Master timeline", onBack = back)
        if (all.isEmpty()) {
            Text("No dated events yet.", modifier = Modifier.padding(16.dp))
        } else {
            ChipRow {
                FilterChip(selected = topicSel == null, onClick = { topicSel = null }, label = { Text("All topics") })
                topicsWith.forEach { n ->
                    FilterChip(selected = topicSel == n, onClick = { topicSel = n }, label = { Text("Topic $n") })
                }
            }
            ChipRow {
                FilterChip(selected = regionSel == null, onClick = { regionSel = null }, label = { Text("All regions") })
                regions.forEach { r ->
                    FilterChip(selected = regionSel == r, onClick = { regionSel = r }, label = { Text(r) })
                }
            }
            Text(
                text = "Events come from the chronology table of ${topicsWith.size} of ${state.topics.size} added topics. " +
                    "Regions are tagged automatically from keywords, so check any that look wrong.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                items(shown) { e ->
                    Row(Modifier.padding(vertical = 8.dp)) {
                        Text(text = e.year, fontWeight = FontWeight.Bold, modifier = Modifier.width(110.dp))
                        Column(Modifier.weight(1f)) {
                            Text(text = e.event)
                            Text(
                                text = "Topic ${e.topicNo} \u00B7 ${e.region}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// ---------- Outlines ----------

private fun outlineText(t: Topic): String = buildString {
    append("Outline: ").append(t.title).append("\n\n")
    append("Introduction\n").append(introOf(t)).append("\n\nMain points")
    t.sections.forEachIndexed { i, s -> append("\n").append(i + 1).append(". ").append(s.title) }
    if (t.revision.isNotEmpty()) {
        append("\n\nRevision points")
        t.revision.forEach { append("\n\u2022 ").append(it) }
    }
    append("\n\n- PMS International Affairs app")
}

private fun introOf(t: Topic): String =
    t.overview.split(Regex("(?<=[.!?])\\s+")).take(2).joinToString(" ")

@Composable
fun OutlineScreen(state: AppState, t: Topic, back: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Outline \u00B7 Topic ${t.no}", onBack = back, actions = {
            TextButton(onClick = { copyText(ctx, "Outline", outlineText(t)) }) { Text("Copy") }
            TextButton(onClick = { shareText(ctx, outlineText(t)) }) { Text("Share") }
        })
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(text = t.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Introduction", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        GText(state, introOf(t))
                    }
                }
            }
            item { Text("Main points (tap to open key points)", style = MaterialTheme.typography.bodySmall) }
            itemsIndexed(t.sections) { i, s ->
                var expanded by remember { mutableStateOf(false) }
                Card(Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            text = "${i + 1}. ${s.title}  ${if (expanded) "\u25BE" else "\u25B8"}",
                            fontWeight = FontWeight.Bold
                        )
                        if (expanded) {
                            Spacer(Modifier.height(6.dp))
                            s.keyPoints.forEach { GText(state, "\u2022 $it") }
                        }
                    }
                }
            }
            if (t.revision.isNotEmpty()) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Revision points", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            t.revision.forEach { GText(state, "\u2022 $it") }
                        }
                    }
                }
            }
        }
    }
}

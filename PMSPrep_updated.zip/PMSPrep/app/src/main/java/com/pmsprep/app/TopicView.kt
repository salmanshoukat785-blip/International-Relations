package com.pmsprep.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val tabNames = listOf("Notes", "Key Points", "MCQs", "Vocabulary", "My Notes")

@Composable
private fun noteHeadingColor(): Color =
    if (MaterialTheme.colorScheme.background.luminance() < 0.5f) Color(0xFF4DD0E1) else Color(0xFF0E7C86)

@Composable
fun TopicScreen(state: AppState, t: Topic, back: () -> Unit, open: (Screen) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val saveKey = "${t.no}:t"
    val saved = saveKey in state.bookmarks
    val studied = t.no.toString() in state.revised
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("${t.no}. ${t.title}", onBack = back)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(onClick = { state.toggleBookmark(saveKey) }) {
                Text(if (saved) "★ Saved" else "☆ Save")
            }
            OutlinedButton(onClick = { state.toggleRevised(t.no) }) {
                Text(if (studied) "Studied ✔" else "Mark studied")
            }
        }
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
            tabNames.forEachIndexed { i, name ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(name) })
            }
        }
        when (tab) {
            0 -> NotesTab(state, t, open)
            1 -> KeyPointsTab(state, t)
            2 -> McqTab(state, t, open)
            3 -> VocabTab(t)
            else -> MyNotesTab(state, t)
        }
    }
}

@Composable
private fun NotesTab(state: AppState, t: Topic, open: (Screen) -> Unit) {
    var long by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Short", fontWeight = if (!long) FontWeight.Bold else FontWeight.Normal)
            Switch(checked = long, onCheckedChange = { long = it }, modifier = Modifier.padding(horizontal = 12.dp))
            Text("Long detail", fontWeight = if (long) FontWeight.Bold else FontWeight.Normal)
        }
        Spacer(Modifier.height(8.dp))
        GText(state, t.overview)
        Text(
            text = "Underlined words are difficult terms. Tap one to see its meaning.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(vertical = 6.dp)
        )
        t.sections.forEachIndexed { i, s ->
            NoteCard(state, t, i, s, long)
            Spacer(Modifier.height(10.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (t.chronology.isNotEmpty()) {
                OutlinedButton(onClick = { open(Screen.ChronoOf(t.no)) }) { Text("Dates and timeline") }
            }
            OutlinedButton(onClick = { open(Screen.OutlineOf(t.no)) }) { Text("Topic outline") }
        }
        Spacer(Modifier.height(10.dp))
        t.extras.forEachIndexed { k, ex ->
            Card(Modifier.fillMaxWidth(), colors = cardTint(k + t.sections.size)) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        text = ex.title.ifBlank { "Facts and developments" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = noteHeadingColor()
                    )
                    Spacer(Modifier.height(6.dp))
                    ex.text.split("\n\n").forEach { para ->
                        GText(state, para)
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        if (t.references.isNotEmpty()) {
            Text("References", fontWeight = FontWeight.Bold)
            t.references.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        }
        if (t.note.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(text = t.note, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun cardTint(i: Int) =
    if (i % 2 == 0) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
    else CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)

@Composable
private fun NoteCard(state: AppState, t: Topic, idx: Int, s: SubSection, long: Boolean) {
    val ctx = LocalContext.current
    val key = "${t.no}:$idx"
    val saved = key in state.bookmarks
    Card(Modifier.fillMaxWidth(), colors = cardTint(idx)) {
        Column(Modifier.padding(14.dp)) {
            Text(
                text = "${idx + 1}. ${s.title}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = noteHeadingColor()
            )
            Spacer(Modifier.height(6.dp))
            GText(state, if (long) s.long else s.short)
            Row {
                TextButton(onClick = { state.toggleBookmark(key) }) { Text(if (saved) "★ Saved" else "☆ Save") }
                TextButton(onClick = { copyText(ctx, s.title, sectionText(t.title, s)) }) { Text("Copy") }
                TextButton(onClick = { shareText(ctx, sectionText(t.title, s)) }) { Text("Share") }
            }
            OnlineTools(state, t.no, idx, s)
        }
    }
}

@Composable
private fun KeyPointsTab(state: AppState, t: Topic) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        t.sections.forEachIndexed { i, s ->
            Card(Modifier.fillMaxWidth(), colors = cardTint(i)) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        text = "${i + 1}. ${s.title}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = noteHeadingColor()
                    )
                    Spacer(Modifier.height(4.dp))
                    s.keyPoints.forEach { GText(state, "• $it") }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        if (t.revision.isNotEmpty()) {
            Card(Modifier.fillMaxWidth(), colors = cardTint(t.sections.size)) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        text = "Key points for revision",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = noteHeadingColor()
                    )
                    Spacer(Modifier.height(4.dp))
                    t.revision.forEach {
                        GText(state, "• $it")
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun McqTab(state: AppState, t: Topic, open: (Screen) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        OutlinedButton(onClick = { open(Screen.QuizOf(t.no)) }, modifier = Modifier.fillMaxWidth()) {
            Text("Start timed practice (${t.mcqs.size} MCQs)")
        }
        Spacer(Modifier.height(10.dp))
        t.mcqs.forEachIndexed { qi, q ->
            var picked by remember(t.no, qi) { mutableIntStateOf(-1) }
            Card(Modifier.fillMaxWidth(), colors = cardTint(qi)) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        text = "Q${qi + 1}. ${q.q}",
                        fontWeight = FontWeight.Bold,
                        color = noteHeadingColor()
                    )
                    Spacer(Modifier.height(6.dp))
                    q.options.forEachIndexed { oi, opt ->
                        val label = "${'A' + oi}. $opt"
                        val mark = when {
                            picked < 0 -> ""
                            oi == q.answer -> "  ✔"
                            oi == picked -> "  ✘"
                            else -> ""
                        }
                        Text(
                            text = label + mark,
                            fontWeight = if (picked >= 0 && oi == q.answer) FontWeight.Bold else FontWeight.Normal,
                            color = if (picked >= 0 && oi == picked && oi != q.answer) MaterialTheme.colorScheme.error
                            else androidx.compose.ui.graphics.Color.Unspecified,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = picked < 0) {
                                    picked = oi
                                    if (oi != q.answer) state.addWrong(q) else state.removeWrong(q)
                                }
                                .padding(vertical = 8.dp)
                        )
                    }
                    if (picked >= 0 && q.explanation.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(text = q.explanation, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun VocabTab(t: Topic) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        t.vocab.forEachIndexed { i, v ->
            Card(Modifier.fillMaxWidth(), colors = cardTint(i)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(v.term, fontWeight = FontWeight.Bold, color = noteHeadingColor())
                        Text(v.meaning)
                    }
                    TextButton(onClick = { copyText(ctx, v.term, vocabText(v)) }) { Text("Copy") }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun MyNotesTab(state: AppState, t: Topic) {
    var text by remember(t.no) { mutableStateOf(state.myNote(t.no)) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Your own notes for this topic (saved on this phone).", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it; state.saveNote(t.no, it) },
            label = { Text("Write here") },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
    }
}

package com.pmsprep.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Optional online helpers: Urdu translation and extended detail. Everything else stays offline. */
object Online {
    private const val MODEL = "claude-sonnet-5-5"

    private const val URDU_PROMPT =
        "Translate the following Pakistan International Affairs study notes into clear, standard Urdu " +
            "for a CSS/PMS candidate. Keep numbers, dates, names and acronyms exactly as given. " +
            "Where a technical term is useful, write the Urdu followed by the English term in brackets. " +
            "Output only the Urdu translation, with no preface."

    private const val EXTEND_PROMPT =
        "You are helping a Punjab PMS (International Affairs, Paper 9) candidate. Expand the notes below into a " +
            "more detailed explanation of about 300 words in English: add background, causes, " +
            "arguments for and against, and an exam-style conclusion. Use only facts you are confident about, " +
            "do not invent figures or dates, and say clearly where something may have changed or should be " +
            "verified. Do not repeat the notes word for word. Output only the explanation."

    suspend fun ask(apiKey: String, instruction: String, notes: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val body = JSONObject()
                    .put("model", MODEL)
                    .put("max_tokens", 2000)
                    .put(
                        "messages",
                        JSONArray().put(
                            JSONObject().put("role", "user").put("content", instruction + "\n\n" + notes)
                        )
                    )
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                try {
                    c.requestMethod = "POST"
                    c.connectTimeout = 15000
                    c.readTimeout = 90000
                    c.doOutput = true
                    c.setRequestProperty("content-type", "application/json")
                    c.setRequestProperty("x-api-key", apiKey)
                    c.setRequestProperty("anthropic-version", "2023-06-01")
                    c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = c.responseCode
                    val stream = if (code in 200..299) c.inputStream else c.errorStream
                    val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    if (code !in 200..299) {
                        val msg = runCatching {
                            JSONObject(text).getJSONObject("error").getString("message")
                        }.getOrDefault(text.take(200))
                        error(
                            when (code) {
                                401 -> "API key sahi nahi (401). Settings mein check karein."
                                429 -> "Limit ya rate limit (429). Thori der baad try karein."
                                else -> "Error $code: $msg"
                            }
                        )
                    }
                    val arr = JSONObject(text).getJSONArray("content")
                    buildString {
                        for (i in 0 until arr.length()) {
                            val part = arr.getJSONObject(i)
                            if (part.optString("type") == "text") append(part.optString("text"))
                        }
                    }.trim().ifEmpty { error("Khali jawab aaya.") }
                } finally {
                    c.disconnect()
                }
            }
        }

    fun urdu(apiKey: String, notes: String) = suspend { ask(apiKey, URDU_PROMPT, notes) }
    fun extend(apiKey: String, notes: String) = suspend { ask(apiKey, EXTEND_PROMPT, notes) }

    fun friendly(t: Throwable): String = when (t) {
        is java.net.UnknownHostException, is java.net.SocketTimeoutException, is java.net.ConnectException ->
            "Internet nahi mil raha. Connection check karein."
        else -> t.message ?: "Kuch ghalat ho gaya."
    }
}

/** Buttons under each section: Urdu translation and extended detail. Results are cached for offline reading. */
@Composable
fun OnlineTools(state: AppState, no: Int, idx: Int, s: SubSection) {
    val scope = rememberCoroutineScope()
    val urduKey = "urdu:$no:$idx"
    val extKey = "ext:$no:$idx"
    var urdu by remember { mutableStateOf(state.aiCached(urduKey)) }
    var ext by remember { mutableStateOf(state.aiCached(extKey)) }
    var showUrdu by remember { mutableStateOf(false) }
    var showExt by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    fun notes() = buildString {
        append(s.title).append("\n").append(s.short).append("\n").append(s.long)
        s.keyPoints.forEach { append("\n- ").append(it) }
    }

    fun run(kind: String, cacheKey: String, instruction: suspend () -> Result<String>, set: (String) -> Unit) {
        if (state.apiKey.isBlank()) {
            error = "Pehle More > Settings > Online features mein API key daalein."
            return
        }
        loading = kind
        error = ""
        scope.launch {
            val r = instruction()
            loading = ""
            r.onSuccess { state.aiSave(cacheKey, it); set(it) }
                .onFailure { error = Online.friendly(it) }
        }
    }

    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = {
                if (urdu != null) showUrdu = !showUrdu
                else {
                    run("urdu", urduKey, Online.urdu(state.apiKey, notes())) { urdu = it; showUrdu = true }
                }
            }, enabled = loading.isEmpty()) {
                Text(if (urdu != null && showUrdu) "Hide اردو" else "اردو (Urdu)")
            }
            TextButton(onClick = {
                if (ext != null) showExt = !showExt
                else {
                    run("ext", extKey, Online.extend(state.apiKey, notes())) { ext = it; showExt = true }
                }
            }, enabled = loading.isEmpty()) {
                Text(if (ext != null && showExt) "Hide extended" else "Extend online")
            }
            if (loading.isNotEmpty()) {
                CircularProgressIndicator(Modifier.size(20.dp).padding(top = 8.dp), strokeWidth = 2.dp)
            }
        }
        if (error.isNotEmpty()) {
            Text(text = error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        if (showUrdu && urdu != null) {
            Spacer(Modifier.height(6.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("اردو ترجمہ", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Text(
                            text = urdu!!,
                            fontSize = 18.sp,
                            lineHeight = 32.sp,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Text(
                        "AI translation hai; imtihan se pehle important facts English notes se mila lein.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { urdu = null; showUrdu = false; state.aiClear(urduKey) }) {
                        Text("Delete saved translation")
                    }
                }
            }
        }
        if (showExt && ext != null) {
            Spacer(Modifier.height(6.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Extended detail (AI)", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    GText(state, ext!!)
                    Text(
                        "AI-generated: figures aur dates khud verify karein.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { ext = null; showExt = false; state.aiClear(extKey) }) {
                        Text("Delete / regenerate")
                    }
                }
            }
        }
    }
}

/** Settings block for the optional online features. */
@Composable
fun OnlineSettings(state: AppState) {
    var key by remember { mutableStateOf(state.apiKey) }
    Column {
        Text("Online features (optional)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Urdu translation aur Extend online ke liye internet aur apni Anthropic API key chahiye. " +
                "Key sirf is phone mein save hoti hai aur sirf api.anthropic.com ko bheji jati hai; " +
                "har request ka kharcha aap ke account se hota hai. Jo jawab aa jaye wo offline bhi dikhta hai.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = key,
            onValueChange = { key = it },
            label = { Text("Anthropic API key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { state.changeApiKey(key) }) { Text("Save key") }
            OutlinedButton(onClick = { key = ""; state.changeApiKey("") }) { Text("Remove key") }
        }
        if (state.apiKey.isNotBlank()) Text("Key saved.", style = MaterialTheme.typography.bodySmall)
    }
}

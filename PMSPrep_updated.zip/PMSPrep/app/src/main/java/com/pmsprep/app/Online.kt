package com.pmsprep.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Optional online helpers: Urdu translation and extended detail. Everything else stays offline. */
object Online {
    private const val MODEL = "claude-sonnet-5-5"

    private const val URDU_PROMPT =
        "Translate the following Pakistan International Affairs study notes into clear, standard Urdu " +
            "for a CSS/PMS candidate. Keep numbers, dates, names and acronyms exactly as given. " +
            "Where a technical term is useful, write the Urdu followed by the English term in brackets. " +
            "Output only the Urdu translation, with no preface."

    private const val EXTEND_PROMPT =
        "You are helping a Punjab PMS (International Affairs, Paper 9) candidate. Expand the notes below into a " +
            "more detailed explanation of about 300 words in English: add background, causes, " +
            "arguments for and against, and an exam-style conclusion. Use only facts you are confident about, " +
            "do not invent figures or dates, and say clearly where something may have changed or should be " +
            "verified. Do not repeat the notes word for word. Output only the explanation."

    private class ApiErr(val code: Int, message: String) : Exception(message)

    private fun http(url: String, method: String, headers: Map<String, String>, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = 90000
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                    .getOrDefault(text.take(200))
                throw ApiErr(code, msg)
            }
            return text
        } finally {
            c.disconnect()
        }
    }

    private fun geminiCall(key: String, model: String, prompt: String): String {
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))
            )
            .put("generationConfig", JSONObject().put("maxOutputTokens", 2000))
        val text = http(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            "POST", mapOf("x-goog-api-key" to key), body.toString()
        )
        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        return buildString {
            for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
        }.trim().ifEmpty { error("Khali jawab aaya.") }
    }

    private fun claudeCall(key: String, prompt: String): String {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 2000)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val text = http(
            "https://api.anthropic.com/v1/messages", "POST",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString()
        )
        val arr = JSONObject(text).getJSONArray("content")
        return buildString {
            for (i in 0 until arr.length()) {
                val part = arr.getJSONObject(i)
                if (part.optString("type") == "text") append(part.optString("text"))
            }
        }.trim().ifEmpty { error("Khali jawab aaya.") }
    }

    /** Models that this key can use for text generation, as reported by Google. */
    suspend fun listModels(key: String): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            val text = http(
                "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
                "GET", mapOf("x-goog-api-key" to key), null
            )
            val arr = JSONObject(text).getJSONArray("models")
            val out = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods")
                var ok = false
                if (methods != null) for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
                if (ok) out.add(m.getString("name").removePrefix("models/"))
            }
            out
        }
    }

    /** Best fast text model from the list: a Flash model, preferring stable, non-lite and newest. */
    fun pickModel(names: List<String>): String? {
        val bad = listOf("image", "tts", "live", "audio", "embed", "vision", "robotics", "computer", "gemma", "learnlm", "aqa", "exp", "thinking")
        val cand = names.filter { n -> n.contains("flash") && bad.none { n.contains(it) } }
        return cand.sortedWith(
            compareByDescending<String> { !it.contains("preview") }
                .thenByDescending { !it.contains("lite") }
                .thenByDescending { it }
        ).firstOrNull()
    }

    private fun mapErr(e: ApiErr, gemini: Boolean, model: String): String {
        val keyBad = e.code == 401 || (gemini && (e.code == 403 ||
            (e.code == 400 && (e.message ?: "").contains("API key", ignoreCase = true))))
        return when {
            keyBad -> "API key sahi nahi (${e.code}). Settings mein check karein."
            e.code == 404 && gemini -> "Model '$model' nahi mila (404). Settings mein 'Find model' dabayein."
            e.code == 429 -> "Limit ya rate limit (429). Thori der baad try karein."
            else -> "Error ${e.code}: ${e.message}"
        }
    }

    suspend fun ask(state: AppState, instruction: String, notes: String): Result<String> {
        val gemini = state.provider == "gemini"
        val key = state.activeKey()
        val prompt = instruction + "\n\n" + notes
        var model = state.geminiModel
        val r = withContext(Dispatchers.IO) {
            runCatching {
                if (!gemini) claudeCall(key, prompt)
                else try {
                    geminiCall(key, model, prompt)
                } catch (e: ApiErr) {
                    if (e.code != 404) throw e
                    // Saved model is gone: ask Google which models exist and retry once.
                    val best = listModels(key).getOrNull()?.let { pickModel(it) }
                    if (best == null || best == model) throw e
                    val out = geminiCall(key, best, prompt)
                    model = best
                    out
                }
            }.recoverCatching { t ->
                if (t is ApiErr) error(mapErr(t, gemini, model)) else throw t
            }
        }
        if (gemini && r.isSuccess && model != state.geminiModel) state.changeGeminiModel(model)
        return r
    }

    fun urdu(state: AppState, notes: String) = suspend { ask(state, URDU_PROMPT, notes) }
    fun extend(state: AppState, notes: String) = suspend { ask(state, EXTEND_PROMPT, notes) }

    fun friendly(t: Throwable): String = when (t) {
        is java.net.UnknownHostException, is java.net.SocketTimeoutException, is java.net.ConnectException ->
            "Internet nahi mil raha. Connection check karein."
        else -> t.message ?: "Kuch ghalat ho gaya."
    }
}

/** Buttons under each section: Urdu translation and extended detail. Results are cached for offline reading. */
@Composable
fun OnlineTools(state: AppState, no: Int, idx: Int, s: SubSection) {
    val scope = rememberCoroutineScope()
    val urduKey = "urdu:$no:$idx"
    val extKey = "ext:$no:$idx"
    var urdu by remember { mutableStateOf(state.aiCached(urduKey)) }
    var ext by remember { mutableStateOf(state.aiCached(extKey)) }
    var showUrdu by remember { mutableStateOf(false) }
    var showExt by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    fun notes() = buildString {
        append(s.title).append("\n").append(s.short).append("\n").append(s.long)
        s.keyPoints.forEach { append("\n- ").append(it) }
    }

    fun run(kind: String, cacheKey: String, instruction: suspend () -> Result<String>, set: (String) -> Unit) {
        if (state.activeKey().isBlank()) {
            error = "Pehle More > Settings > Online features mein key daalein."
            return
        }
        loading = kind
        error = ""
        scope.launch {
            val r = instruction()
            loading = ""
            r.onSuccess { state.aiSave(cacheKey, it); set(it) }
                .onFailure { error = Online.friendly(it) }
        }
    }

    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = {
                if (urdu != null) showUrdu = !showUrdu
                else {
                    run("urdu", urduKey, Online.urdu(state, notes())) { urdu = it; showUrdu = true }
                }
            }, enabled = loading.isEmpty()) {
                Text(if (urdu != null && showUrdu) "Hide اردو" else "اردو (Urdu)")
            }
            TextButton(onClick = {
                if (ext != null) showExt = !showExt
                else {
                    run("ext", extKey, Online.extend(state, notes())) { ext = it; showExt = true }
                }
            }, enabled = loading.isEmpty()) {
                Text(if (ext != null && showExt) "Hide extended" else "Extend online")
            }
            if (loading.isNotEmpty()) {
                CircularProgressIndicator(Modifier.size(20.dp).padding(top = 8.dp), strokeWidth = 2.dp)
            }
        }
        if (error.isNotEmpty()) {
            Text(text = error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        if (showUrdu && urdu != null) {
            Spacer(Modifier.height(6.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("اردو ترجمہ", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Text(
                            text = urdu!!,
                            fontSize = 18.sp,
                            lineHeight = 32.sp,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Text(
                        "AI translation hai; imtihan se pehle important facts English notes se mila lein.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { urdu = null; showUrdu = false; state.aiClear(urduKey) }) {
                        Text("Delete saved translation")
                    }
                }
            }
        }
        if (showExt && ext != null) {
            Spacer(Modifier.height(6.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Extended detail (AI)", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    GText(state, ext!!)
                    Text(
                        "AI-generated: figures aur dates khud verify karein.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { ext = null; showExt = false; state.aiClear(extKey) }) {
                        Text("Delete / regenerate")
                    }
                }
            }
        }
    }
}

/** Settings block for the optional online features. */
@Composable
fun OnlineSettings(state: AppState) {
    val gemini = state.provider == "gemini"
    var key by remember(state.provider) { mutableStateOf(state.activeKey()) }
    var model by remember { mutableStateOf(state.geminiModel) }
    var testing by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val clean = key.filter { !it.isWhitespace() }
    fun save() {
        if (gemini) { state.changeGeminiKey(clean); state.changeGeminiModel(model) } else state.changeApiKey(clean)
        key = clean
    }
    Column {
        Text("Online features (optional)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Urdu translation aur Extend online ke liye internet aur ek AI key chahiye. " +
                "Key sirf is phone mein save hoti hai aur sirf usi company ke server ko bheji jati hai. " +
                "Jo jawab aa jaye wo offline bhi dikhta hai.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.material3.FilterChip(
                selected = gemini,
                onClick = { state.changeProvider("gemini"); result = "" },
                label = { Text("Gemini (free key)") }
            )
            androidx.compose.material3.FilterChip(
                selected = !gemini,
                onClick = { state.changeProvider("claude"); result = "" },
                label = { Text("Claude (paid key)") }
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = if (gemini) "Free key: aistudio.google.com/apikey par Google account se 'Create API key'. Key 'AIza...' se shuru hoti hai."
            else "Paid key: Anthropic Console > API Keys. Key 'sk-ant-...' se shuru hoti hai.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = key,
            onValueChange = { key = it; result = "" },
            label = { Text(if (gemini) "Gemini API key" else "Anthropic API key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        val preview = if (clean.length > 12) clean.take(6) + "..." + clean.takeLast(4) else clean
        Text(
            text = if (clean.isEmpty()) "Key abhi khali hai." else "Aap ne daali: $preview (${clean.length} characters)" +
                if (clean.length < 30) "\nWarning: key bohat chhoti lag rahi hai, poori copy karein." else "",
            style = MaterialTheme.typography.bodySmall
        )
        if (gemini) {
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; result = "" },
                label = { Text("Gemini model name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(
                enabled = clean.isNotEmpty() && !testing,
                onClick = {
                    testing = true
                    result = "Models dhoonde ja rahe hain..."
                    scope.launch {
                        val r = Online.listModels(clean)
                        testing = false
                        result = r.fold(
                            onSuccess = { list ->
                                val best = Online.pickModel(list)
                                if (best == null) "Koi flash model nahi mila. List: " + list.take(8).joinToString(", ")
                                else {
                                    model = best; state.changeGeminiKey(clean); state.changeGeminiModel(best)
                                    "Model set: $best (kul ${list.size} models). Ab Test dabayein."
                                }
                            },
                            onFailure = { Online.friendly(it) }
                        )
                    }
                }
            ) { Text("Find model") }
            Text(
                "Find model Google se aap ki key ke liye maujooda model dhoond kar khud set kar deta hai.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { save(); result = "Save ho gayi." }) { Text("Save") }
            OutlinedButton(
                enabled = clean.isNotEmpty() && !testing,
                onClick = {
                    save()
                    testing = true
                    result = "Test ho raha hai..."
                    scope.launch {
                        val r = Online.ask(state, "Reply with the single word OK.", "ping")
                        testing = false
                        result = r.fold(
                            onSuccess = { "Key theek hai \u2714 (jawab: ${it.take(30)})" },
                            onFailure = { Online.friendly(it) }
                        )
                    }
                }
            ) { Text("Test") }
            OutlinedButton(onClick = {
                key = ""
                if (gemini) state.changeGeminiKey("") else state.changeApiKey("")
                result = "Key hata di gayi."
            }) { Text("Remove key") }
        }
        if (result.isNotEmpty()) Text(result, style = MaterialTheme.typography.bodySmall)
    }
}

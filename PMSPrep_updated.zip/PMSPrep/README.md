# PMS International Affairs (Paper 9) – study app

Native Android app (Kotlin + Jetpack Compose). Works offline.

## Build the APK on GitHub
1. Create a new GitHub repository and push this whole folder to the `main` branch.
2. Open the repo > **Actions** > **Build APK** (runs automatically on every push, or press *Run workflow*).
3. When it turns green, open the run and download **PMSPrep-debug-apk** from *Artifacts*. Unzip it and install `app-debug.apk` on your phone (allow "install unknown apps").

## Adding a topic
Topic content lives in `app/src/main/assets/content/` (`index.json` + `topic_NN.json`).
Add the new `topic_NN.json`, replace `index.json`, push, and download the new APK.

## App screens
Splash, onboarding, Topics, MCQs (quiz, mock test, wrong-answers bank), Revise (quick revision cards, master timeline, outlines), Saved, More (Settings, User guide, About, Intro). Difficult words are underlined in notes; tap for the meaning.

## Practice
Timed mock test, wrong-answers bank and spaced revision (3/7/15 days).

## Adding topics automatically
Upload each new topic .docx file to the GitHub repo (any folder, for example `topics/`). On every push the
workflow converts all topic .docx files in the repo into app data (`tools/build_content.py`) and builds the APK.
Notes, MCQs, revision cards, outlines, timeline and underlined difficult words all read from that data, so
nothing else needs changing. The log shows a line per file, such as `OK ... 13 sub-sections, 15 MCQs, ...`.

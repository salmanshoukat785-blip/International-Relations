"""Turn a topic study file (.docx) into the markdown-like text convert_topic.py reads.

Needs python-docx (pip install python-docx).
"""
from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph


def _runs_md(p):
    parts = []  # list of [bold, text]
    for r in p.runs:
        t = r.text
        if not t:
            continue
        b = bool(r.bold)
        if parts and parts[-1][0] == b:
            parts[-1][1] += t
        else:
            parts.append([b, t])
    out = ""
    for b, t in parts:
        if b and t.strip():
            out += "**" + t + "**"
        else:
            out += t
    return out


def _para_md(p):
    style = (p.style.name or "") if p.style is not None else ""
    if style.startswith("Heading 1"):
        return "# " + p.text.strip()
    if style.startswith("Heading 2"):
        return "## " + p.text.strip()
    return _runs_md(p).strip()


def _table_md(t):
    rows = []
    for ri, row in enumerate(t.rows):
        cells = [c.text.replace("\n", " ").strip() for c in row.cells]
        rows.append("| " + " | ".join(cells) + " |")
        if ri == 0:
            rows.append("| " + " | ".join("---" for _ in cells) + " |")
    return "\n".join(rows)


def docx_to_md(path):
    doc = Document(path)
    blocks = []
    for child in doc.element.body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            md = _para_md(Paragraph(child, doc))
            if md:
                blocks.append(md)
        elif tag == "tbl":
            blocks.append(_table_md(Table(child, doc)))
    return "\n\n".join(blocks) + "\n"


if __name__ == "__main__":
    import sys
    print(docx_to_md(sys.argv[1]))

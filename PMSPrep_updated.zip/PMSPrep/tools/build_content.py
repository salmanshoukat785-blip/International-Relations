#!/usr/bin/env python3
"""Convert every topic .docx in a folder into app data (JSON) automatically.

Usage: python3 tools/build_content.py <folder-with-docx-files>

For each file: reads it, builds app/src/main/assets/content/topic_NN.json and marks the
topic as completed in index.json. Every app feature (topics list, notes, MCQs, revision
cards, outlines, timeline, underlined difficult words) reads from that data, so a new topic
shows up everywhere without any code change.
"""
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from convert_topic import parse, save  # noqa: E402
from docx_to_md import docx_to_md  # noqa: E402


def main():
    folder = pathlib.Path(sys.argv[1])
    files = sorted(folder.glob("*.docx"))
    if not files:
        print("No .docx files found in", folder)
        return 0
    failed = []
    for f in files:
        md = docx_to_md(str(f))
        if not (re.search(r"TOPIC \d+:", md) or re.search(r"(?m)^Topic \d+:", md)):
            print(f"SKIPPED (not a topic file): {f.name}")
            continue
        try:
            data = parse(md)
            if not data["sections"]:
                raise ValueError("no sub-sections found")
            name = save(data)
        except Exception as ex:  # report clearly, keep going so every problem is listed
            failed.append(f.name)
            print(f"::error::Could not read topic file {f.name}: {ex}")
            continue
        print(
            f"OK {f.name} -> {name}: {len(data['sections'])} sub-sections, "
            f"{len(data['mcqs'])} MCQs, {len(data['vocab'])} vocabulary words, "
            f"{len(data['chronology'])} timeline events"
        )
        if not data["mcqs"]:
            print(f"::warning::{f.name}: no MCQs were found")
        if not data["vocab"]:
            print(f"::warning::{f.name}: no vocabulary words were found")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

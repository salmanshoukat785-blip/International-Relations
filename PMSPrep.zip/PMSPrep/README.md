# PMS International Affairs (Paper 9) – study app

Native Android app (Kotlin + Jetpack Compose). Works offline.

## Build the APK on GitHub
1. Create a new GitHub repository and push this whole folder to the `main` branch.
2. Open the repo > **Actions** > **Build APK** (runs automatically on every push, or press *Run workflow*).
3. When it turns green, open the run and download **PMSPrep-debug-apk** from *Artifacts*. Unzip it and install `app-debug.apk` on your phone (allow "install unknown apps").

## Adding a topic
Topic content lives in `app/src/main/assets/content/` (`index.json` + `topic_NN.json`).
Add the new `topic_NN.json`, replace `index.json`, push, and download the new APK.

## App screens
Splash, onboarding, Topics, Saved, More (Settings, User guide, About, Intro). Difficult words are underlined in notes; tap for the meaning. Copy/Share on notes.

## Practice
Timed mock test, wrong-answers bank and spaced revision (3/7/15 days).

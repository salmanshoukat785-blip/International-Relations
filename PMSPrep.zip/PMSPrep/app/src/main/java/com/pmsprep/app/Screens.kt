package com.pmsprep.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed interface Screen {
    data class OpenTopic(val no: Int) : Screen
    data class ChronoOf(val no: Int) : Screen
    data class QuizOf(val no: Int?) : Screen
    data class VocabOf(val no: Int) : Screen
    data class FlashOf(val no: Int?) : Screen
    object QuizBank : Screen
    object MockSetup : Screen
    data class MockRun(val count: Int) : Screen
    object Settings : Screen
    object Guide : Screen
    object About : Screen
    object Intro : Screen
}

// ---------- Root ----------

@Composable
fun AppRoot(state: AppState) {
    val stack = remember { mutableStateListOf<Screen>() }
    var tab by remember { mutableIntStateOf(0) }
    BackHandler(enabled = stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }
    val top = stack.lastOrNull()
    val open: (Screen) -> Unit = { stack.add(it) }
    val back: () -> Unit = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

    Scaffold(
        bottomBar = {
            if (top == null) {
                NavigationBar {
                    val labels = listOf("Topics", "Quiz", "Vocab", "Saved", "More")
                    val icons = listOf("\uD83D\uDCDA", "\uD83D\uDCDD", "\uD83D\uDD24", "\u2605", "\u2699")
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(icons[i]) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        androidx.compose.foundation.layout.Box(Modifier.padding(pad).fillMaxSize()) {
            when (top) {
                null -> when (tab) {
                    0 -> TopicsTab(state, open)
                    1 -> QuizTab(state, open)
                    2 -> VocabScreen(state, null, null, open)
                    3 -> SavedTab(state)
                    else -> MoreTab(open)
                }
                is Screen.OpenTopic -> state.topics[top.no]?.let { TopicScreen(state, it, back, open) }
                is Screen.ChronoOf -> state.topics[top.no]?.let { ChronoScreen(it, back) }
                is Screen.QuizOf -> QuizScreen(state, top.no, back)
                is Screen.VocabOf -> VocabScreen(state, top.no, back, open)
                is Screen.FlashOf -> FlashScreen(state, top.no, back)
                Screen.QuizBank -> BankQuizScreen(state, back)
                Screen.MockSetup -> MockSetupScreen(state, back, open)
                is Screen.MockRun -> MockTestScreen(state, top.count, back)
                Screen.Settings -> SettingsScreen(state, back, open)
                Screen.Guide -> GuideScreen(back)
                Screen.About -> AboutScreen(state, back)
                Screen.Intro -> OnboardingScreen(onDone = back)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenHeader(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        title = { Text(text = title, maxLines = 1) },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) { Text(text = "\u2190", fontSize = 22.sp) }
        },
        actions = actions
    )
}

// ---------- Topics tab ----------

@Composable
fun TopicsTab(state: AppState, open: (Screen) -> Unit) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("PMS International Affairs")
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search notes and vocabulary") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
        )
        if (query.isBlank()) TopicList(state, open) else SearchResults(state, query.trim(), open)
    }
}

@Composable
fun TopicList(state: AppState, open: (Screen) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { ProgressCard(state) }
        val due = state.dueTopics()
        if (due.isNotEmpty()) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Due for revision", fontWeight = FontWeight.Bold)
                        due.forEach { t ->
                            TextButton(onClick = { open(Screen.OpenTopic(t.no)) }) {
                                Text("Topic ${t.no}: ${t.title}")
                            }
                        }
                    }
                }
            }
        }
        state.index.groupBy { it.section }.forEach { (section, entries) ->
            item {
                Text(
                    text = section,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(entries, key = { it.no }) { e ->
                val ready = state.topics.containsKey(e.no)
                val revised = e.no.toString() in state.revised
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .alpha(if (ready) 1f else 0.5f)
                        .clickable(enabled = ready) { open(Screen.OpenTopic(e.no)) }
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "${e.no}.", fontWeight = FontWeight.Bold, modifier = Modifier.width(34.dp))
                        Column(Modifier.weight(1f)) {
                            Text(text = e.title)
                            Text(
                                text = when {
                                    !ready -> "Pending"
                                    revised && state.isDue(e.no) -> "Revised \u2714 \u00B7 review due"
                                    revised -> "Revised \u2714"
                                    else -> "Ready"
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProgressCard(state: AppState) {
    val total = state.index.size
    val ready = state.topics.size
    val revised = state.topics.keys.count { it.toString() in state.revised }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(text = "$ready of $total topics added \u00B7 $revised revised", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { if (ready == 0) 0f else revised.toFloat() / ready },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun SearchResults(state: AppState, query: String, open: (Screen) -> Unit) {
    val q = query.lowercase()
    val noteHits = state.topics.values.flatMap { t ->
        t.sections.filter { s ->
            s.title.lowercase().contains(q) || s.short.lowercase().contains(q) ||
                s.long.lowercase().contains(q) || s.keyPoints.any { it.lowercase().contains(q) }
        }.map { s -> t to s }
    }
    val vocabHits = state.topics.values.flatMap { it.vocab }.filter {
        it.term.lowercase().contains(q) || it.meaning.lowercase().contains(q)
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (noteHits.isEmpty() && vocabHits.isEmpty()) item { Text("No results.") }
        if (noteHits.isNotEmpty()) item { Text("Notes", fontWeight = FontWeight.Bold) }
        items(noteHits) { (t, s) ->
            Card(Modifier.fillMaxWidth().clickable { open(Screen.OpenTopic(t.no)) }) {
                Column(Modifier.padding(12.dp)) {
                    Text(text = s.title, fontWeight = FontWeight.Bold)
                    Text(text = "Topic ${t.no}: ${t.title}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (vocabHits.isNotEmpty()) item { Text("Vocabulary", fontWeight = FontWeight.Bold) }
        items(vocabHits) { v -> VocabRow(v) }
    }
}

// ---------- Topic detail ----------

@Composable
fun TopicScreen(state: AppState, t: Topic, back: () -> Unit, open: (Screen) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Topic ${t.no}", onBack = back)
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(text = t.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(text = t.overview)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (t.chronology.isNotEmpty()) {
                        OutlinedButton(onClick = { open(Screen.ChronoOf(t.no)) }, modifier = Modifier.weight(1f)) { Text("Dates") }
                    }
                    OutlinedButton(onClick = { open(Screen.QuizOf(t.no)) }, modifier = Modifier.weight(1f)) { Text("Quiz") }
                    OutlinedButton(onClick = { open(Screen.VocabOf(t.no)) }, modifier = Modifier.weight(1f)) { Text("Vocab") }
                }
            }
            item {
                val done = t.no.toString() in state.revised
                Column {
                    FilterChip(
                        selected = done,
                        onClick = { state.toggleRevised(t.no) },
                        label = { Text(if (done) "Revised \u2714" else "Mark as revised") }
                    )
                    if (done) {
                        val days = state.daysUntilReview(t.no)
                        val level = state.reviewLevel(t.no)
                        Spacer(Modifier.height(6.dp))
                        if (days == null) {
                            Text("All 3 spaced reviews completed \u2714", style = MaterialTheme.typography.bodySmall)
                        } else if (days <= 0) {
                            Button(onClick = { state.markReviewed(t.no) }) {
                                Text("Review due: mark reviewed (${level + 1}/3)")
                            }
                        } else {
                            Text("Next review in $days day(s) (${level + 1}/3)", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            itemsIndexed(t.sections) { i, s -> SectionCard(state, t.no, i, s) }
            if (t.revision.isNotEmpty()) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                text = "Key points for revision",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(6.dp))
                            t.revision.forEach { pt ->
                                Text(text = "\u2022 $pt")
                                Spacer(Modifier.height(4.dp))
                            }
                        }
                    }
                }
            }
            if (t.facts.isNotBlank()) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                text = t.factsTitle.ifBlank { "Facts and developments" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(6.dp))
                            t.facts.split("\n\n").forEach { para ->
                                Text(text = para)
                                Spacer(Modifier.height(8.dp))
                            }
                        }
                    }
                }
            }
            if (t.references.isNotEmpty()) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                text = "References",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(6.dp))
                            t.references.forEach { ref ->
                                Text(text = "\u2022 $ref", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(4.dp))
                            }
                        }
                    }
                }
            }
            if (t.note.isNotBlank()) {
                item { Text(text = t.note, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
fun SectionCard(state: AppState, no: Int, idx: Int, s: SubSection) {
    var expanded by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val topicTitle = state.topics[no]?.title ?: ""
    val key = "$no:$idx"
    val saved = key in state.bookmarks
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = s.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { state.toggleBookmark(key) }) {
                    Text(text = if (saved) "\u2605" else "\u2606", fontSize = 22.sp)
                }
            }
            Text(text = s.short)
            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Text(text = s.long)
                Spacer(Modifier.height(8.dp))
                Text(text = "Key points", fontWeight = FontWeight.Bold)
                s.keyPoints.forEach { Text(text = "\u2022 $it") }
            }
            Row {
                TextButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "Hide detail" else "Show detail")
                }
                TextButton(onClick = { copyText(ctx, s.title, sectionText(topicTitle, s)) }) { Text("Copy") }
                TextButton(onClick = { shareText(ctx, sectionText(topicTitle, s)) }) { Text("Share") }
            }
        }
    }
}

@Composable
fun ChronoScreen(t: Topic, back: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Timeline \u00B7 Topic ${t.no}", onBack = back)
        LazyColumn(contentPadding = PaddingValues(12.dp)) {
            items(t.chronology) { c ->
                Row(Modifier.padding(vertical = 8.dp)) {
                    Text(text = c.year, fontWeight = FontWeight.Bold, modifier = Modifier.width(110.dp))
                    Text(text = c.event, modifier = Modifier.weight(1f))
                }
                HorizontalDivider()
            }
        }
    }
}

// ---------- Quiz ----------

@Composable
fun QuizTab(state: AppState, open: (Screen) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Quiz")
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val all = state.topics.values.sumOf { it.mcqs.size }
            item {
                Card(Modifier.fillMaxWidth().clickable(enabled = all > 0) { open(Screen.QuizOf(null)) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Mixed quiz (all topics)", fontWeight = FontWeight.Bold)
                        Text("$all questions, shuffled", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth().clickable { open(Screen.MockSetup) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Timed mock test", fontWeight = FontWeight.Bold)
                        Text("Exam-style, one minute per question, with score breakdown", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                val n = state.wrongMcqs().size
                Card(Modifier.fillMaxWidth().clickable(enabled = n > 0) { open(Screen.QuizBank) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Wrong answers bank", fontWeight = FontWeight.Bold)
                        Text(
                            if (n > 0) "$n questions to review. Answer correctly to clear them."
                            else "Empty. Questions you get wrong will collect here.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            items(state.topics.values.toList()) { t ->
                Card(Modifier.fillMaxWidth().clickable { open(Screen.QuizOf(t.no)) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Topic ${t.no}: ${t.title}")
                        Text("${t.mcqs.size} questions", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

// ---------- Vocabulary ----------

@Composable
fun VocabRow(v: VocabItem) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(text = v.term, fontWeight = FontWeight.Bold)
                Text(text = v.meaning)
            }
            TextButton(onClick = { copyText(ctx, v.term, vocabText(v)) }) { Text("Copy") }
        }
    }
}

@Composable
fun VocabScreen(state: AppState, no: Int?, back: (() -> Unit)?, open: (Screen) -> Unit) {
    var query by remember { mutableStateOf("") }
    val list = state.vocabFor(no).filter {
        query.isBlank() || it.term.contains(query, ignoreCase = true) || it.meaning.contains(query, ignoreCase = true)
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(if (no == null) "Vocabulary" else "Vocab \u00B7 Topic $no", onBack = back, actions = {
            TextButton(onClick = { open(Screen.FlashOf(no)) }) { Text("Flashcards") }
        })
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search words") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list) { v -> VocabRow(v) }
        }
    }
}

@Composable
fun FlashScreen(state: AppState, no: Int?, back: () -> Unit) {
    val cards = remember(no) { state.vocabFor(no).shuffled() }
    var i by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Flashcards", onBack = back)
        if (cards.isEmpty()) {
            Text("No words yet.", modifier = Modifier.padding(12.dp))
        } else {
            val c = cards[i]
            Column(Modifier.padding(16.dp)) {
                Text(text = "${i + 1} / ${cards.size}", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().height(220.dp).clickable { flipped = !flipped }
                ) {
                    Column(
                        Modifier.fillMaxSize().padding(20.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (flipped) c.meaning else c.term,
                            style = MaterialTheme.typography.titleLarge,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = if (flipped) "(tap to see English)" else "(tap to see Roman Urdu)",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = i > 0,
                        onClick = { i--; flipped = false },
                        modifier = Modifier.weight(1f)
                    ) { Text("Previous") }
                    Button(
                        enabled = i < cards.size - 1,
                        onClick = { i++; flipped = false },
                        modifier = Modifier.weight(1f)
                    ) { Text("Next") }
                }
            }
        }
    }
}

// ---------- Saved ----------

private data class SavedItem(val no: Int, val idx: Int, val topic: Topic, val section: SubSection)

@Composable
fun SavedTab(state: AppState) {
    val items = state.bookmarks.mapNotNull { key ->
        val p = key.split(":")
        val no = p.getOrNull(0)?.toIntOrNull() ?: return@mapNotNull null
        val idx = p.getOrNull(1)?.toIntOrNull() ?: return@mapNotNull null
        val t = state.topics[no] ?: return@mapNotNull null
        val s = t.sections.getOrNull(idx) ?: return@mapNotNull null
        SavedItem(no, idx, t, s)
    }.sortedWith(compareBy({ it.no }, { it.idx }))
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Saved notes")
        if (items.isEmpty()) {
            Text("Tap the star on any note to save it here.", modifier = Modifier.padding(16.dp))
        }
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items, key = { "${it.no}:${it.idx}" }) { it2 ->
                Text(text = "Topic ${it2.no}", style = MaterialTheme.typography.bodySmall)
                SectionCard(state, it2.no, it2.idx, it2.section)
            }
        }
    }
}

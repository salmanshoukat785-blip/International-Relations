package com.pmsprep.app

data class IndexEntry(val no: Int, val section: String, val title: String, val file: String?)
data class SubSection(val title: String, val short: String, val long: String, val keyPoints: List<String>)
data class ChronoItem(val year: String, val event: String)
data class Mcq(val q: String, val options: List<String>, val answer: Int)
data class VocabItem(val term: String, val meaning: String)
data class Topic(
    val no: Int,
    val title: String,
    val overview: String,
    val sections: List<SubSection>,
    val chronology: List<ChronoItem>,
    val mcqs: List<Mcq>,
    val vocab: List<VocabItem>
)

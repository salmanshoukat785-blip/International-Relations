package com.pmsprep.app

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject

private fun JSONArray.objs(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
private fun JSONArray.strs(): List<String> = (0 until length()).map { getString(it) }

object Repo {
    private fun read(ctx: Context, path: String): String =
        ctx.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }

    fun loadIndex(ctx: Context): List<IndexEntry> =
        JSONArray(read(ctx, "content/index.json")).objs().map { o ->
            IndexEntry(
                no = o.getInt("no"),
                section = o.getString("section"),
                title = o.getString("title"),
                file = if (o.isNull("file")) null else o.getString("file")
            )
        }

    fun loadTopic(ctx: Context, e: IndexEntry): Topic? {
        val file = e.file ?: return null
        return try {
            val o = JSONObject(read(ctx, "content/$file"))
            Topic(
                no = o.getInt("no"),
                title = o.getString("title"),
                overview = o.optString("overview"),
                sections = o.getJSONArray("sections").objs().map { s ->
                    SubSection(
                        s.getString("title"), s.getString("short"), s.getString("long"),
                        s.getJSONArray("keyPoints").strs()
                    )
                },
                chronology = (o.optJSONArray("chronology") ?: JSONArray()).objs().map {
                    ChronoItem(it.getString("year"), it.getString("event"))
                },
                facts = o.optString("facts"),
                factsTitle = o.optString("factsTitle"),
                references = (o.optJSONArray("references") ?: JSONArray()).strs(),
                revision = (o.optJSONArray("revision") ?: JSONArray()).strs(),
                note = o.optString("note"),
                mcqs = o.getJSONArray("mcqs").objs().map {
                    Mcq(it.getString("q"), it.getJSONArray("options").strs(), it.getInt("answer"), it.optString("explanation"))
                },
                vocab = o.getJSONArray("vocab").objs().map {
                    VocabItem(it.getString("term"), it.getString("meaning"))
                }
            )
        } catch (ex: Exception) {
            Log.e("Repo", "Failed to load $file", ex)
            null
        }
    }
}

package com.pmsprep.app

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

data class PaletteDef(
    val name: String,
    val light: Color,
    val lightContainer: Color,
    val dark: Color,
    val darkContainer: Color
)

val palettes = listOf(
    PaletteDef("Navy", Color(0xFF1F4E79), Color(0xFFD3E4F7), Color(0xFF9CC3EB), Color(0xFF1F4E79)),
    PaletteDef("Green", Color(0xFF2E6B3E), Color(0xFFD1EBD6), Color(0xFF9ED3A8), Color(0xFF2E6B3E)),
    PaletteDef("Maroon", Color(0xFF8A2B3A), Color(0xFFF5D6DA), Color(0xFFE7A3AD), Color(0xFF8A2B3A)),
    PaletteDef("Teal", Color(0xFF00695C), Color(0xFFCCEBE6), Color(0xFF80CBC4), Color(0xFF00695C))
)

fun colorSchemeFor(index: Int, dark: Boolean): ColorScheme {
    val p = palettes.getOrElse(index) { palettes[0] }
    return if (dark) {
        darkColorScheme(
            primary = p.dark,
            onPrimary = Color(0xFF101418),
            primaryContainer = p.darkContainer,
            onPrimaryContainer = Color.White,
            secondaryContainer = p.darkContainer,
            onSecondaryContainer = Color.White
        )
    } else {
        lightColorScheme(
            primary = p.light,
            primaryContainer = p.lightContainer,
            onPrimaryContainer = Color(0xFF10212F),
            secondaryContainer = p.lightContainer,
            onSecondaryContainer = Color(0xFF10212F)
        )
    }
}

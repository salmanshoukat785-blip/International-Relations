package com.pmsprep.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class AppState(ctx: Context) {
    private val sp = ctx.getSharedPreferences("pms_prefs", Context.MODE_PRIVATE)

    val index: List<IndexEntry> = Repo.loadIndex(ctx)
    val topics: Map<Int, Topic> = index.mapNotNull { e ->
        Repo.loadTopic(ctx, e)?.let { e.no to it }
    }.toMap()

    var bookmarks by mutableStateOf(sp.getStringSet("bookmarks", emptySet())!!.toSet())
        private set
    var revised by mutableStateOf(sp.getStringSet("revised", emptySet())!!.toSet())
        private set
    var themeMode by mutableIntStateOf(sp.getInt("theme", 0)) // 0 auto, 1 light, 2 dark
        private set

    fun toggleBookmark(key: String) {
        bookmarks = if (key in bookmarks) bookmarks - key else bookmarks + key
        sp.edit().putStringSet("bookmarks", bookmarks.toSet()).apply()
    }

    fun toggleRevised(no: Int) {
        val k = no.toString()
        revised = if (k in revised) revised - k else revised + k
        sp.edit().putStringSet("revised", revised.toSet()).apply()
    }

    fun cycleTheme() {
        themeMode = (themeMode + 1) % 3
        sp.edit().putInt("theme", themeMode).apply()
    }

    fun themeLabel() = when (themeMode) { 1 -> "Light"; 2 -> "Dark"; else -> "Auto" }

    fun vocabFor(no: Int?): List<VocabItem> =
        if (no == null) topics.values.flatMap { it.vocab } else topics[no]?.vocab ?: emptyList()
}

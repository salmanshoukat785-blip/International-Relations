package com.pmsprep.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class AppState(ctx: Context) {
    private val sp = ctx.getSharedPreferences("pms_prefs", Context.MODE_PRIVATE)

    val index: List<IndexEntry> = Repo.loadIndex(ctx)
    val topics: Map<Int, Topic> = index.mapNotNull { e ->
        Repo.loadTopic(ctx, e)?.let { e.no to it }
    }.toMap()

    var bookmarks by mutableStateOf(sp.getStringSet("bookmarks", emptySet())!!.toSet())
        private set
    var revised by mutableStateOf(sp.getStringSet("revised", emptySet())!!.toSet())
        private set
    var themeMode by mutableIntStateOf(sp.getInt("theme", 0)) // 0 auto, 1 light, 2 dark
        private set
    var palette by mutableIntStateOf(sp.getInt("palette", 0))
        private set
    var fontScale by mutableFloatStateOf(sp.getFloat("font_scale", 1f))
        private set
    var onboarded by mutableStateOf(sp.getBoolean("onboarded", false))
        private set

    fun toggleBookmark(key: String) {
        bookmarks = if (key in bookmarks) bookmarks - key else bookmarks + key
        sp.edit().putStringSet("bookmarks", bookmarks.toSet()).apply()
    }

    fun toggleRevised(no: Int) {
        val k = no.toString()
        revised = if (k in revised) revised - k else revised + k
        sp.edit().putStringSet("revised", revised.toSet()).apply()
    }

    fun setThemeMode(mode: Int) {
        themeMode = mode
        sp.edit().putInt("theme", mode).apply()
    }

    fun setPalette(index: Int) {
        palette = index
        sp.edit().putInt("palette", index).apply()
    }

    fun setFontScale(scale: Float) {
        fontScale = scale
        sp.edit().putFloat("font_scale", scale).apply()
    }

    fun finishOnboarding() {
        onboarded = true
        sp.edit().putBoolean("onboarded", true).apply()
    }

    fun resetProgress() {
        bookmarks = emptySet()
        revised = emptySet()
        sp.edit().putStringSet("bookmarks", emptySet()).putStringSet("revised", emptySet()).apply()
    }

    fun vocabFor(no: Int?): List<VocabItem> =
        if (no == null) topics.values.flatMap { it.vocab } else topics[no]?.vocab ?: emptyList()
}

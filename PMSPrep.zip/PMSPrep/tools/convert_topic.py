#!/usr/bin/env python3
"""Convert a topic study file (markdown text extracted from the .docx) into
app/src/main/assets/content/topic_NN.json and mark it as completed in index.json.

Usage: python3 tools/convert_topic.py topic.md
"""
import json, re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
CONTENT = ROOT / "app/src/main/assets/content"


def clean(s):
    return re.sub(r"\s+", " ", s.replace("**", "")).strip()


def parse(md):
    m = re.search(r"\*\*TOPIC (\d+):\s*(.+?)\*\*", md)
    no, title = int(m.group(1)), clean(m.group(2)).title()
    parts, cur = {}, None
    for line in md.splitlines():
        if line.startswith("# "):
            cur = line[2:].strip()
            parts[cur] = []
        elif cur is not None:
            parts[cur].append(line)
    get = lambda name: "\n".join(next((v for k, v in parts.items() if k.startswith(name)), []))

    ov = get("Topic Overview")
    overview = clean(ov.split("\n## ")[0]) if "\n## " not in ov else clean(ov.split("\n## ")[0])
    # first '## ' split
    blocks = re.split(r"(?m)^## ", ov)
    overview = clean(blocks[0])
    sections = []
    for b in blocks[1:]:
        lines = b.strip().splitlines()
        stitle = re.sub(r"^\d+\.\s*", "", lines[0]).strip()
        body = "\n".join(lines[1:])
        short = re.search(r"\*\*Short detail:\s*\*\*\s*(.+)", body)
        long_ = re.search(r"\*\*Long detail:\s*\*\*\s*(.+)", body)
        kp = body.split("**Key points**")[-1].strip().splitlines() if "**Key points**" in body else []
        sections.append({
            "title": stitle,
            "short": clean(short.group(1)) if short else "",
            "long": clean(long_.group(1)) if long_ else "",
            "keyPoints": [clean(x) for x in kp if x.strip()],
        })

    chrono = []
    for item in get("Topic-specific Chronology").replace("\n", " ").split(";"):
        c = re.match(r"^\s*(\d{3,4}(?:–\d{2,4})?)\s+–\s+(.+?)\.?\s*$", item)
        if c:
            chrono.append({"year": c.group(1), "event": clean(c.group(2))})

    mcq_text = get("Topic-specific MCQs")
    mcqs, cur_q = [], None
    for line in mcq_text.splitlines():
        line = line.strip()
        q = re.match(r"^\*\*(\d+)\.\s+(.+?)\*\*$", line)
        o = re.match(r"^([A-D])\.\s+(.+)$", line)
        if q:
            cur_q = {"q": clean(q.group(2)), "options": [], "answer": 0}
            mcqs.append(cur_q)
        elif o and cur_q is not None:
            cur_q["options"].append(clean(o.group(2)))
    key = re.search(r"Answer Key:(.+)", mcq_text)
    if key:
        for n, letter in re.findall(r"(\d+)-([A-D])", key.group(1)):
            mcqs[int(n) - 1]["answer"] = "ABCD".index(letter)

    vocab = []
    for line in get("Difficult Vocabulary").splitlines():
        cells = [clean(c) for c in line.strip().strip("|").split("|")]
        if len(cells) == 2 and not set(cells[0]) <= set("- ") and cells[0] != "English Term":
            vocab.append({"term": cells[0], "meaning": cells[1]})

    return {"no": no, "title": title, "overview": overview, "sections": sections,
            "chronology": chrono, "mcqs": mcqs, "vocab": vocab}


def main():
    md = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
    data = parse(md)
    fname = f"topic_{data['no']:02d}.json"
    CONTENT.mkdir(parents=True, exist_ok=True)
    (CONTENT / fname).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    idx_path = CONTENT / "index.json"
    idx = json.loads(idx_path.read_text(encoding="utf-8"))
    for e in idx:
        if e["no"] == data["no"]:
            e["file"] = fname
            data["title"] = e["title"]
    (CONTENT / fname).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    idx_path.write_text(json.dumps(idx, ensure_ascii=False, indent=1), encoding="utf-8")
    print(fname, {k: len(v) for k, v in data.items() if isinstance(v, list)})


if __name__ == "__main__":
    main()
